package W05;


class ComplexNumber{
    int real;
    int imag;
    String print_sum(){
        return (real + " + " + imag + "i");
    }
    String print_mult(){
        return (real + " * " + imag + "i");
    }
}

public class W05_Q_2 {
    public static void main(String[] args) {
        ComplexNumber cn = new ComplexNumber();
        cn.real = 10;
        cn.imag = 21;
        System.out.println(cn.print_sum());
        System.out.println(cn.print_mult());
    }
}